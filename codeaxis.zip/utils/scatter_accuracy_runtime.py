import pandas as pd
import matplotlib.pyplot as plt

def plot_accuracy_runtime_scatter():
    df = pd.read_csv("generated/benchmark_log.csv")

    plt.figure(figsize=(10, 6))

    # Classical scatter
    plt.scatter(df["Classical Runtime (s)"], df["Classical Accuracy"], label="Classical ML", color="#4CAF50", marker="o")

    # Quantum scatter
    plt.scatter(df["Quantum Runtime (s)"], df["Quantum Accuracy"], label="Quantum ML", color="#2196F3", marker="x")

    # Labels and layout
    plt.title("Accuracy vs Runtime Scatter Plot")
    plt.xlabel("Runtime (seconds)")
    plt.ylabel("Accuracy")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("generated/accuracy_runtime_scatter.png")
    plt.close()