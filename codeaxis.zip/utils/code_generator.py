import os

def generate_code(prompt, logic_type):
    os.makedirs("generated", exist_ok=True)

    if logic_type == "ai":
        code = f"""from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Load dataset
digits = load_digits()
X, y = digits.data, digits.target

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Evaluate
accuracy = model.score(X_test, y_test)
print("Accuracy:", accuracy)
"""

    elif logic_type == "quantum":
        code = f"""from qiskit_machine_learning.algorithms import QSVC
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

# Load dataset
digits = load_digits()
X, y = digits.data, digits.target

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train quantum model
model = QSVC()
model.fit(X_train, y_train)

# Evaluate
accuracy = model.score(X_test, y_test)
print("Quantum Accuracy:", accuracy)
"""

    elif logic_type == "dsa":
        # Basic DSA prompt matching
        if "prime" in prompt.lower():
            code = """def is_prime(n):
    if n <= 1:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True

# Example usage
num = 29
print(f"{num} is prime:", is_prime(num))
"""
        elif "reverse" in prompt.lower() and "linked list" in prompt.lower():
            code = """class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def reverse_linked_list(head):
    prev = None
    current = head
    while current:
        next_node = current.next
        current.next = prev
        prev = current
        current = next_node
    return prev

# Example usage
head = Node(1)
head.next = Node(2)
head.next.next = Node(3)
reversed_head = reverse_linked_list(head)
while reversed_head:
    print(reversed_head.data, end=" ")
    reversed_head = reversed_head.next
"""
        else:
            code = f"""# DSA logic placeholder for prompt: {prompt}
def solve():
    print("Implement logic for: {prompt}")

solve()
"""

    else:
        code = "# Unknown logic type. Please select AI, Quantum, or DSA."

    code_path = os.path.join("generated", "generated_code.py")
    with open(code_path, "w") as f:
        f.write(code)

    return code_path