def recommend_logic_mode(classical_acc, quantum_acc, classical_time, quantum_time):
    tradeoff_classical = classical_acc / classical_time if classical_time else 0
    tradeoff_quantum = quantum_acc / quantum_time if quantum_time else 0

    if tradeoff_classical > tradeoff_quantum:
        return "AI"
    elif tradeoff_quantum > tradeoff_classical:
        return "Quantum"
    else:
        return "AI"  # Default fallback

def explain_tradeoff(classical_acc, quantum_acc, classical_time, quantum_time):
    classical_score = round(classical_acc / classical_time, 3) if classical_time else 0
    quantum_score = round(quantum_acc / quantum_time, 3) if quantum_time else 0

    explanation = (
        f"Classical Tradeoff Score: {classical_score} (Accuracy {classical_acc:.2f} / Time {classical_time:.2f}s)\n"
        f"Quantum Tradeoff Score: {quantum_score} (Accuracy {quantum_acc:.2f} / Time {quantum_time:.2f}s)\n"
    )

    recommended = recommend_logic_mode(classical_acc, quantum_acc, classical_time, quantum_time)
    explanation += f"\n🧠 Recommended Mode: {recommended} — based on best tradeoff score."

    return explanation