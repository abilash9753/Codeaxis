import numpy as np
from sklearn.datasets import load_digits

def save_digits_npy():
    digits = load_digits()
    data = digits.data
    target = digits.target
    np.save("generated/digits.npy", {"data": data, "target": target})
    print("✅ digits.npy saved to generated/")

if __name__ == "__main__":
    save_digits_npy()