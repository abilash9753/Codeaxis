import matplotlib.pyplot as plt

def plot_accuracy(classical_acc, quantum_acc):
    labels = ['Classical ML', 'Quantum ML']
    accuracies = [classical_acc, quantum_acc]
    colors = ['#4CAF50', '#2196F3']

    plt.figure(figsize=(6, 5))
    bars = plt.bar(labels, accuracies, color=colors)

    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.01, f'{yval:.2f}', ha='center', va='bottom', fontsize=12)

    plt.ylim(0, 1)
    plt.title('Accuracy Comparison')
    plt.ylabel('Accuracy')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig("generated/benchmark_chart.png")
    plt.close()