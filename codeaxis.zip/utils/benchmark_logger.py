import csv
from datetime import datetime
import os

def log_benchmark(classical_acc, quantum_acc, classical_time, quantum_time):
    folder = "generated"
    os.makedirs(folder, exist_ok=True)
    log_path = f"{folder}/benchmark_log.csv"

    headers = ["Timestamp", "Classical Accuracy", "Quantum Accuracy", "Classical Runtime (s)", "Quantum Runtime (s)"]
    row = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        round(classical_acc, 4),
        round(quantum_acc, 4),
        round(classical_time, 3),
        round(quantum_time, 3)
    ]

    file_exists = os.path.isfile(log_path)
    with open(log_path, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(headers)
        writer.writerow(row)