import pandas as pd
import matplotlib.pyplot as plt

def plot_trend(mode="all", filter_mode="both"):
    df = pd.read_csv("generated/benchmark_log.csv")
    df["Timestamp"] = pd.to_datetime(df["Timestamp"])

    if mode == "recent":
        df = df.sort_values("Timestamp").tail(7)

    plt.figure(figsize=(10, 6))

    if filter_mode in ["both", "classical"]:
        plt.plot(df["Timestamp"], df["Classical Accuracy"], label="Classical Accuracy", marker="o", color="#4CAF50")
        p50 = df["Classical Accuracy"].median()
        p90 = df["Classical Accuracy"].quantile(0.9)
        plt.axhline(p50, color="#888", linestyle="--", linewidth=1, label="Classical Median")
        plt.axhline(p90, color="#FF5722", linestyle=":", linewidth=1, label="Classical Top 10%")

    if filter_mode in ["both", "quantum"]:
        plt.plot(df["Timestamp"], df["Quantum Accuracy"], label="Quantum Accuracy", marker="x", color="#2196F3")
        p50 = df["Quantum Accuracy"].median()
        p90 = df["Quantum Accuracy"].quantile(0.9)
        plt.axhline(p50, color="#888", linestyle="--", linewidth=1, label="Quantum Median")
        plt.axhline(p90, color="#FF5722", linestyle=":", linewidth=1, label="Quantum Top 10%")

    plt.title("Accuracy Trend Over Time")
    plt.xlabel("Timestamp")
    plt.ylabel("Accuracy")
    plt.xticks(rotation=45)
    plt.ylim(0, 1)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("generated/benchmark_trend.png")
    plt.close()