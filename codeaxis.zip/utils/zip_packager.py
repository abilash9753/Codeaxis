import zipfile
import os

def package_code(code_path, summary_text):
    zip_dir = "generated"
    os.makedirs(zip_dir, exist_ok=True)
    zip_path = os.path.join(zip_dir, "latest_package.zip")

    with zipfile.ZipFile(zip_path, 'w') as zipf:
        # Add code file
        if os.path.exists(code_path):
            zipf.write(code_path, arcname=os.path.basename(code_path))

        # Add summary
        summary_path = os.path.join(zip_dir, "summary.txt")
        with open(summary_path, "w") as f:
            f.write(summary_text)
        zipf.write(summary_path, arcname="summary.txt")

        # Add benchmark log if available
        benchmark_path = os.path.join(zip_dir, "benchmark_log.csv")
        if os.path.exists(benchmark_path):
            zipf.write(benchmark_path, arcname="benchmark_log.csv")

    return zip_path