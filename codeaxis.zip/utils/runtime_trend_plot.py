import matplotlib
matplotlib.use('Agg')  # Use non-GUI backend to avoid Tkinter errors

import matplotlib.pyplot as plt
import pandas as pd
import os

def plot_runtime_trend(csv_path='generated/benchmark_log.csv', output_path='generated/runtime_trend.png'):
    if not os.path.exists(csv_path):
        print("CSV file not found.")
        return

    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return

    if df.empty or 'Timestamp' not in df.columns:
        print("No valid data to plot.")
        return

    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df = df.sort_values('Timestamp')

    plt.figure(figsize=(10, 6))

    if 'Classical Runtime (s)' in df.columns:
        plt.plot(df['Timestamp'], df['Classical Runtime (s)'], label='Classical Runtime', marker='o')

    if 'Quantum Runtime (s)' in df.columns:
        plt.plot(df['Timestamp'], df['Quantum Runtime (s)'], label='Quantum Runtime', marker='o')
    else:
        print("Quantum Runtime column missing — skipping quantum plot.")

    plt.xlabel('Timestamp')
    plt.ylabel('Runtime (s)')
    plt.title('⏱️ Runtime Trend Over Time')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()