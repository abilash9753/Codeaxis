import time
import pandas as pd
import os
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from qiskit_machine_learning.algorithms import QSVC
from sklearn.model_selection import train_test_split

def run_benchmark():
    digits = load_digits()
    X = digits.data
    y = digits.target

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Classical benchmark
    start_classical = time.time()
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    classical_runtime = time.time() - start_classical
    classical_accuracy = model.score(X_test, y_test)

    # Quantum benchmark
    try:
        start_quantum = time.time()
        qsvc = QSVC()
        qsvc.fit(X_train, y_train)
        quantum_runtime = time.time() - start_quantum
        quantum_accuracy = qsvc.score(X_test, y_test)
    except Exception as e:
        print(f"Quantum benchmark failed: {e}")
        quantum_runtime = None
        quantum_accuracy = None

    # Log results
    log_path = "generated/benchmark_log.csv"
    os.makedirs("generated", exist_ok=True)

    row = {
        "Timestamp": pd.Timestamp.now(),
        "Classical Runtime (s)": classical_runtime,
        "Quantum Runtime (s)": quantum_runtime if quantum_runtime is not None else 0.0,
        "Classical Accuracy": classical_accuracy,
        "Quantum Accuracy": quantum_accuracy if quantum_accuracy is not None else 0.0
    }

    if os.path.exists(log_path):
        df = pd.read_csv(log_path)
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    else:
        df = pd.DataFrame([row])

    df.to_csv(log_path, index=False)