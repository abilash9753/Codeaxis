import os
import pandas as pd

def generate_summary(code_path, logic_type):
    summary = ""

    if logic_type == "ai":
        summary += "🧠 Classical AI Logic\n"
        summary += "- Uses scikit-learn for digit classification\n"
        summary += "- Fast runtime, suitable for real-time applications\n"
        summary += f"- Code saved at: {code_path}\n"

    elif logic_type == "quantum":
        summary += "⚛️ Quantum Logic\n"
        summary += "- Uses Qiskit for quantum-enhanced classification\n"
        summary += "- Slower runtime, but explores quantum kernel advantages\n"
        summary += f"- Code saved at: {code_path}\n"

    elif logic_type == "dsa":
        summary += "🧮 DSA Logic\n"
        summary += "- Solves a classic algorithmic problem using Python\n"
        summary += "- Suitable for coding interviews and LeetCode-style challenges\n"
        summary += f"- Code saved at: {code_path}\n"

    else:
        summary += "❓ Unknown logic type\n"
        summary += f"- Code saved at: {code_path}\n"

    summary += "\n📦 Packaged with recruiter-ready summary and benchmark logs."

    # Optional: include benchmark count
    benchmark_path = "generated/benchmark_log.csv"
    if os.path.exists(benchmark_path):
        try:
            df = pd.read_csv(benchmark_path)
            summary += f"\n📊 Benchmark entries logged: {len(df)}"
        except:
            summary += "\n📊 Benchmark log unreadable."

    return summary