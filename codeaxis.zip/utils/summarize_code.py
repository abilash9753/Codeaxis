def summarize_code(code):
    lines = code.strip().split('\n')
    summary = []

    if "Flask" in code:
        summary.append("🧠 This module builds a Flask web app with route handling and dynamic form logic.")
    if "sklearn" in code or "LogisticRegression" in code:
        summary.append("📊 Uses classical ML (Logistic Regression) for prediction tasks.")
    if "qiskit" in code or "QuantumCircuit" in code:
        summary.append("⚛️ Implements quantum logic using Qiskit for hybrid ML benchmarking.")
    if "render_template" in code:
        summary.append("🎨 Integrates HTML templates for polished UI/UX.")
    if "request.form" in code:
        summary.append("📥 Accepts user input via web form and processes it dynamically.")
    if "plt" in code or "matplotlib" in code:
        summary.append("📈 Generates visual charts using Matplotlib.")
    if "zipfile" in code:
        summary.append("📦 Packages code and summary into downloadable ZIP format.")
    if "subprocess" in code:
        summary.append("⚙️ Executes generated code and captures output for benchmarking.")
    if "benchmark_log.csv" in code:
        summary.append("🧾 Logs accuracy and runtime for each benchmark run.")

    if not summary:
        summary.append("📄 This module contains general-purpose Python logic.")

    return "\n".join(summary)
    