from flask import Flask, render_template, request, send_from_directory, redirect, url_for
import os
from utils.benchmark_runner import run_benchmark
from utils.runtime_trend_plot import plot_runtime_trend
from utils.summary_generator import generate_summary
from utils.code_generator import generate_code
from utils.zip_packager import package_code

app = Flask(__name__)
RECRUITER_MODE = False

@app.route('/')
def index():
    return render_template('index.html', recruiter_mode=RECRUITER_MODE)

@app.route('/generate_code', methods=['POST'])
def generate_code_route():
    prompt = request.form['prompt']
    logic_type = request.form['logic_type']

    # ✅ Auto-detect DSA logic if not explicitly selected
    if logic_type not in ['ai', 'quantum', 'dsa']:
        if any(keyword in prompt.lower() for keyword in ['prime', 'array', 'tree', 'sort', 'search', 'graph', 'linked list']):
            logic_type = 'dsa'

    code_path = generate_code(prompt, logic_type)
    summary = generate_summary(code_path, logic_type)
    package_code(code_path, summary)
    return render_template('index.html', recruiter_mode=RECRUITER_MODE, summary=summary)

@app.route('/compare_benchmarks')
def compare_benchmarks():
    run_benchmark()
    return redirect(url_for('index'))

@app.route('/show_runtime_trend')
def show_runtime_trend():
    plot_runtime_trend()
    return redirect(url_for('index'))

@app.route('/toggle_recruiter_mode')
def toggle_recruiter_mode():
    global RECRUITER_MODE
    RECRUITER_MODE = not RECRUITER_MODE
    return redirect(url_for('index'))

@app.route('/download_zip')
def download_zip():
    zip_path = os.path.join('generated', 'latest_package.zip')
    return send_from_directory('generated', 'latest_package.zip', as_attachment=True)

@app.route('/generated/<path:filename>')
def serve_generated_file(filename):
    return send_from_directory('generated', filename)

if __name__ == '__main__':
    app.run(debug=True)