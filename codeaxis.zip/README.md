# 🧠 CodeFusion Architect

A full-stack strategist dashboard for generating, benchmarking, and visualizing AI vs Quantum logic modules — built with Flask, Qiskit, and scikit-learn. Designed for recruiter impact, modular deployment, and adaptive benchmarking.

---

## 🚀 Features

- ⚡ Generate code using AI or Quantum logic
- 📥 Download recruiter-ready summaries and ZIP packages
- 📊 Benchmark accuracy and runtime (Classical vs Quantum)
- 📈 Visualize performance trends and tradeoffs
- 🧾 Auto-log results to CSV for reproducibility
- 🧠 Recommend best-performing logic mode
- 🎨 Polished UI with toggles, filters, and charts

---

## 🧩 Folder Structure
