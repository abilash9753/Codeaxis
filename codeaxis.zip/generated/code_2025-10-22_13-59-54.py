# AI-generated code based on prompt: create a even and odd code


from flask import Flask, request, render_template
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_digits
import numpy as np

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    digits = load_digits()
    X = digits.data
    y = digits.target

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    input_data = np.array(request.form.getlist('pixels')).reshape(1, -1)
    prediction = model.predict(input_data)[0]

    return f"Predicted digit: {prediction}"

if __name__ == '__main__':
    app.run(debug=True)
