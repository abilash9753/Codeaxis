import pennylane as qml
from pennylane import numpy as np
import numpy as onp

# Load sample data
X = onp.load('data/digits.npy')[:10]         # First 10 samples
y = onp.load('data/digits_labels.npy')[:10]  # Corresponding labels

# Normalize inputs
X = X / 16.0  # Digits range from 0–16

# Quantum device
dev = qml.device("default.qubit", wires=4)

@qml.qnode(dev)
def circuit(weights, x):
    qml.templates.AngleEmbedding(x[:4], wires=range(4))
    qml.templates.BasicEntanglerLayers(weights, wires=range(4))
    return qml.expval(qml.PauliZ(0))

# Random weights
weights = np.random.randn(3, 4)

# Run prediction
for i in range(10):
    result = circuit(weights, X[i])
    print(f"Sample {i} → Quantum prediction: {result:.4f}")