def generate_qi_code(prompt):
    code = f"""# Quantum-generated code based on prompt: {prompt}

from qiskit import QuantumCircuit, Aer, execute
import numpy as np

def run_quantum_simulation():
    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure_all()

    simulator = Aer.get_backend('qasm_simulator')
    result = execute(qc, simulator, shots=1024).result()
    counts = result.get_counts(qc)

    print("Quantum simulation result:", counts)

if __name__ == "__main__":
    run_quantum_simulation()
"""
    return code