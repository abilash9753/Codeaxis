import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from qiskit.circuit.library import ZZFeatureMap
from qiskit_machine_learning.kernels import QuantumKernel
from qiskit_machine_learning.algorithms import QSVC
from qiskit.utils import algorithm_globals
from qiskit import BasicAer

def run_quantum_benchmark():
    data = np.load("generated/digits.npy", allow_pickle=True).item()
    X = data["data"]
    y = data["target"]

    # Reduce to binary classification (e.g., digits 0 vs 1)
    mask = (y == 0) | (y == 1)
    X = X[mask]
    y = y[mask]

    # Normalize and split
    X = StandardScaler().fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Quantum kernel setup
    feature_map = ZZFeatureMap(feature_dimension=X.shape[1], reps=1)
    backend = BasicAer.get_backend("qasm_simulator")
    quantum_kernel = QuantumKernel(feature_map=feature_map, quantum_instance=backend)

    # QSVC classifier
    qsvc = QSVC(quantum_kernel=quantum_kernel)
    qsvc.fit(X_train, y_train)
    y_pred = qsvc.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print(f"Quantum prediction: {acc:.4f}")

if __name__ == "__main__":
    run_quantum_benchmark()